package trabJav;

public class Emprestimo {

}
