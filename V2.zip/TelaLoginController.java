package trabJav;

public class TelaLoginController {
	private String usuario = "marcoaurelio";
	private String senha = "123";
	
	public boolean verificaUsuarioSenha(String usuario, String senha) {
		if(this.usuario.intern()  == usuario.intern() && this.senha.intern()  == senha.intern() ) {
			return true;
		} else {
			return false;
		}
	}
}
